/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package validation;

import java.util.ArrayList;

/**
 *
 * @author 1450
 */
public class GSTStateCode {
    
   public  ArrayList getStateCode()
   {
       
       ArrayList statecode=new ArrayList();
       statecode.add("01 Jammu & Kashmir");
       statecode.add("02 Himachal Pradesh");
       statecode.add("03 Punjab");
       statecode.add("04 Chandigarh");
       statecode.add("05 Uttarakhand");
       statecode.add("06 Haryana");
       statecode.add("07 Delhi");
       statecode.add("08 Rajasthan");
       statecode.add("09 Uttar Pradesh");
       statecode.add("10 Bihar");
       statecode.add("11 Sikkim");
       statecode.add("12 Arunachal Pradesh");
       statecode.add("13 Nagaland");
       statecode.add("14 Manipur");
       statecode.add("15 Mizoram");
       statecode.add("16 Tripura");
       statecode.add("17 Meghalaya");
       statecode.add("18 Assam");
       statecode.add("19 West Bengal");
       statecode.add("20 Jharkhand");
       statecode.add("21 Orissa");
       statecode.add("22 Chhattisgarh");
       statecode.add("23 Madhya Pradesh");
       statecode.add("24 Gujarat");
       statecode.add("25 Daman & Diu");
       statecode.add("26 Dadra & Nagar Haveli");
       statecode.add("27 Maharashtra");
       statecode.add("28 Andhra Pradesh");
       statecode.add("29 Karnataka");
       statecode.add("30 Goa");
       statecode.add("31 Lakshadweep");
       statecode.add("32 Kerala");
       statecode.add("33 Tamil Nadu");
       statecode.add("34 Puducherry");
       statecode.add("35 Andaman & Nicobar Islands");
       statecode.add("36 Telengana");
       statecode.add("37 Andrapradesh(New)");
       
       return statecode;
       
   }
    
}
